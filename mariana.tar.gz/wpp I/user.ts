import {Grupo} from "./grupo";
import {Repository} from "./repositorio";

export class User{
    private _userId: string;
    protected rep_grupo: Repository<Grupo>;

    constructor(userId: string){
        this._userId = userId;
        this.rep_grupo = new Repository<Grupo>();
    }

	public get userId(): string {
		return this.userId;
	}
    
    hasChat (chatId: string): boolean{
        return this.rep_grupo.has(chatId);
    }

    getChats (): Array<string>{
        return this.rep_grupo.keys();
    }

    showGrupos(): Array<string>{
        let saida = [""];
        let notificacoes = "";
        let lista = this.rep_grupo.values();
        for (let elem of lista){
            notificacoes += elem.grupoId;
            if(elem.unreadCount(this._userId) > 0)
                notificacoes += "(" + elem.unreadCount(this._userId) + ") ";
            saida.push(notificacoes);
            notificacoes = "";
        }
        return saida;
    }

    addGrupo(grupo: Grupo){
        try{
            this.rep_grupo.add(grupo.grupoId, grupo);
            grupo.addUserGrupo(this);
        }catch(e){

        }
    } 

    toString(){
        return this._userId;
    }
}