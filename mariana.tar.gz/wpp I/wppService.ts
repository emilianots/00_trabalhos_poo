import {Repository} from "./repositorio";
import {Grupo} from "./grupo";
import {User} from "./user";

export class WhatsappService{
    private rep_grupo: Repository<Grupo>;
    public rep_user: Repository<User>;

    constructor(){
        this.rep_grupo = new Repository<Grupo>();
        this.rep_user = new Repository<User>();
    }

    addGrupo(userId: string, grupoId: string){   
        let grupo = new Grupo(grupoId);
        this.rep_grupo.add(grupoId, grupo);
        let user = this.rep_user.get(userId);
        user.addGrupo(grupo);
    }

    addUser(userId: string){
        this.rep_user.add(userId, new User(userId));
    }

   /*  showUserChat(userId: string){
        let resp = "";
        for(let key of this.rep_grupo.keys()){
            if(this.rep_grupo.get(key).hasUser(userId)){
                resp += key;
            }
        }
        return resp;
    } */

    showChatUser(userId: string){
        let resp = "";
        let user = this.rep_user.get(userId);
        let chats = user.getChats();
        for(let key of chats){
            resp += key;
        }
        return resp;
    }

    allUsers(): Array<User>{
        return this.rep_user.values();
    }

    getChat(chatId: string){
        if (!this.rep_grupo.has(chatId)){
            throw new Error ("Erro | Grupo não existe.")
        }
        return this.rep_grupo.get(chatId);
    }

    getUser(userId: string){
        return this.rep_user.get(userId);
    }
}
