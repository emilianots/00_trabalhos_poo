export class Repository<T> {
    private mapa: Map<string, T>;
    private nomeTipo: string;

    constructor(nomeTipo: string = ""){
        this.mapa = new Map<string, T>();
        this.nomeTipo = nomeTipo;
    }

    add(key: string, t: T) {
        if(this.mapa.has(key)){
            throw new Error("" + this.nomeTipo + " " + key + " ja existe");
        }
        this.mapa.set(key, t);
    }

    has(key: string): boolean {
        return this.mapa.has(key);
    }

    rm(key: string) {
        if(!this.mapa.delete(key))
            throw new Error(this.nomeTipo + " " + key + " nao existe");
    }
/* get retorna um objeto específico a partir da chave que vc passou, ex: goku que é objeto usuário/pessoa
*/
    get(key: string): T {
        let resp = this.mapa.get(key);
        if(!resp)
            throw new Error(this.nomeTipo + " " + key + " nao existe");
        return resp;
    }

    set(key: string, t: T){
        this.mapa.set(key, t);
    }
/* values: os objetos do mapa, ou seje, contatos dos usuarios
*/
    values(): Array<T>{
        let vet = new Array<T>();
        for(let value of this.mapa.values())
            vet.push(value);
        return vet;
    }
/* ver o nome dos contatos
*/
    keys(): Array<string>{
        let vet = new Array<string>();
        for(let value of this.mapa.keys())
            vet.push(value);
        return vet;
    }

    toString(){
        return this.mapa.values();
    }
}