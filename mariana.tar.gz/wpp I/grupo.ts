import {UserInbox} from "./userInbox";
import {Zap} from "./zap";
import {Repository} from "./repositorio";
import {User} from "./user";

export class Grupo{
    private _grupoId: string;
    protected userInboxes: Map<string, UserInbox>;

    constructor(grupoId: string){
        this._grupoId = grupoId;
        this.userInboxes = new Map<string, UserInbox>();
    }


    public get grupoId(): string {
        return this._grupoId;
    }

/* getMsgs (userId: string, qtd: number): Zap[]{
    return 
} */

    deliverZap (userId: string, msg: Zap){

    }

    unreadCount (userId: string): number{
        let inbox = this.userInboxes.get(userId);
        if (inbox)
            return inbox.unreadCount();
        /*retorno padrão
        */
        return 0;
    }

/* hasUser (userId: string): boolean{
    return this.rgUserInbox.find(x => x.user.userId == userId) != undefined;
} */

    addUserGrupo (user: User){
        if(this.userInboxes.has(user.userId))
            return;
        this.userInboxes.set(user.userId, new UserInbox(user));
        user.addGrupo(this);
    }

/* addByInvite (user: User, invited: User, grupo: string){
    if(!this.rep_chat.has(grupo)){
        throw new Error ("Erro | Grupo não existe");
    }
    else if(!this.hasUser(user.userId)){
        throw new Error ("Erro | Usuário principal não está no grupo")
    }
    this.addUserChat(invited);
} */

/* rmUserChat (user: User){
    for(let key of this.rep_chat.keys()){
        if(this.rep_chat.get(key).hasUser(user.userId)){
            user.userId.split(user.userId, 1);
        }
    }
    throw new Error("Erro | Este usuário não existe")
} */

}
